package com.example.personalitytest;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CallLog;
import android.provider.ContactsContract.Data;
import android.provider.ContactsContract.CommonDataKinds.GroupMembership;
import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.util.Log;
import android.view.Window;
import android.widget.TextView;

public class MeasureActivity1 extends Activity {	
	private int flag=0;
	private int count=0;
	private int groupe_count=0;
	private int id2;
	private int id1;
	private int[] in_count=new int[256];
	private String[] in_name=new String[256];
	private int[][] in_duration=new int[256][256];
	private int[] out_count=new int[256];
	private String[] out_name=new String[256];
	private int[][] out_duration=new int[256][256];
	private int i=0;
	private int in_sum=0;
	private int in_flag=0;
	private int out_sum=0;
	private int out_flag=0;
	private int out_calling=0;
	private int duration_sum=0;
	private int value_CP;
	private int value_NP;
	private int value_A;
	private int value_FC;
	private int value_AC;
	private double base_NP=22.89;
	private double base_FC=149.29*60;
	private double base_AC=base_FC/(30.13+22.89);
	private int calender_count=0;
	private int[] calender=new int[8];
	private int in_max=0;
	private int out_max=0;
	private int call_max=0;
	
	private TextView cp1;
	private TextView cp2;
	private TextView np1;
	private TextView a1;
	private TextView fc1;
	private TextView ac1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.measure);
		Log.v("MeasureActivity1", "画面遷移成功");
		
		cp1 = (TextView) findViewById(R.id.cp1);
		cp2 = (TextView) findViewById(R.id.cp2);
		np1 = (TextView) findViewById(R.id.np1);
		a1 = (TextView) findViewById(R.id.a1);
		fc1 = (TextView) findViewById(R.id.fc1);
		ac1 = (TextView) findViewById(R.id.ac1);
		
		//電話帳に登録している人の中でグループ登録している人の数の割合
		
		ContentResolver groupe_cr1 = getContentResolver();
        Cursor groupe_c1 = groupe_cr1.query(
        		android.provider.ContactsContract.RawContactsEntity.CONTENT_URI,
        		null,
        		null, 
        		null, 
        		null);
        ContentResolver groupe_cr = getContentResolver();
    	Cursor groupe_c = groupe_cr.query(Data.CONTENT_URI,
				    			new String[] {
    								GroupMembership._ID,
    								GroupMembership.CONTACT_ID,
    								GroupMembership.LOOKUP_KEY,
    								GroupMembership.PHOTO_ID,
    								GroupMembership.DISPLAY_NAME,
    								GroupMembership.GROUP_ROW_ID
    								},
    								Data.MIMETYPE + " = ? ",
    							new String[] {
    								GroupMembership.CONTENT_ITEM_TYPE,
    								},
    							null);
    	if (groupe_c.moveToFirst()) {
    		do {
    			groupe_count++; 
    		} while (groupe_c.moveToNext()); 
    	}
    	if (groupe_c1.moveToFirst()) {
    		do {
    			id1 = groupe_c1.getInt(groupe_c1.getColumnIndex("contact_id"));            	 
    			if(flag==0){
    				flag=1;
    				id2=id1;
    				}
    			if(id1!=id2){
               		count++;
               		id2=id1;
               		}
               	else{
               		id2=id1;
               	}
    		}while (groupe_c1.moveToNext());    
    	}
    	//Log.v("AddressActivity", "人の総数"+count); 
    	
    	//Log.v("MeasureActivity1","総数："+count+",登録している人："+groupe_count);
    	if(groupe_count*100/count>80)
    		value_CP=-5;
    	else if(groupe_count*100/count>60)
    		value_CP=4;
    	else if(groupe_count*100/count>40)
    		value_CP=3;
    	else if(groupe_count*100/count>20)
    		value_CP=2;
    	else if(groupe_count*100/count>=0)
    		value_CP=1;
    	cp1.setText(""+count);
    	cp2.setText(""+groupe_count);
    	Log.v("MeasureActivity","CP測定完了");
    	
    	//カレンダーからスケジュール取得
    	ContentResolver groupe_cr2 = getContentResolver();
        Cursor groupe_c2 = groupe_cr2.query(
        		android.provider.CalendarContract.Events.CONTENT_URI,
        		null,
        		null, 
        		null, 
        		null);
        long now=System.currentTimeMillis();
        
        if (groupe_c2.moveToFirst()) {
    		do {
    			long start = groupe_c2.getLong(groupe_c2.getColumnIndex(CalendarContract.Events.DTSTART));
    			if(now<start&&start<now+7*24*60*60*1000){
    				if(start<now+1*24*60*60*1000)
    					calender[0]++;
    				else if(start<now+2*24*60*60*1000)
    					calender[1]++;
    				else if(start<now+3*24*60*60*1000)
    					calender[2]++;
    				else if(start<now+4*24*60*60*1000)
    					calender[3]++;
    				else if(start<now+5*24*60*60*1000)
    					calender[4]++;
    				else if(start<now+6*24*60*60*1000)
    					calender[5]++;
    				else if(start<now+7*24*60*60*1000)
    					calender[6]++;
    			}
    		}while (groupe_c2.moveToNext());    
    	}
        for(int i=0;i<7;i++){
        	if(calender[i]>0)
        		calender_count++;
        }
        //Log.v("MeasureActivity1","一週間の予定の数："+calender[0]+calender[1]+calender[2]+calender[3]+calender[4]+calender[5]+calender[6]);
        if(calender_count*100/7>80)
        	value_A=5;
        else if(calender_count*100/7>60)
        	value_A=4;
        else if(calender_count*100/7>40)
        	value_A=3;
        else if(calender_count*100/7>20)
        	value_A=2;
        else if(calender_count*100/7>=0)
        	value_A=1;
        
        a1.setText(""+calender[0]+calender[1]+calender[2]+calender[3]+calender[4]+calender[5]+calender[6]);
        Log.v("MeasureActivity","A測定完了");
        
        //通話履歴情報取得
        for(i=0;i<256;i++){
        	out_count[i]=0;
        	out_name[i]="";
        	for(int j=0;j<256;j++)
        		out_duration[i][j]=0;
        }
        for(i=0;i<256;i++){
        	in_count[i]=0;
        	in_name[i]="";
        	for(int j=0;j<256;j++)
        		in_duration[i][j]=0;
        }

        ContentResolver contentResolver = getContentResolver();
        Cursor c = contentResolver.query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DEFAULT_SORT_ORDER);
       
     
     if (c.moveToFirst()) {
         do {
        	 String number = c.getString(c.getColumnIndex(CallLog.Calls.NUMBER));
        	 String type = c.getString(c.getColumnIndex(CallLog.Calls.TYPE));
        	 long date = c.getLong(c.getColumnIndex(CallLog.Calls.DATE));
        	 int duration = c.getInt(c.getColumnIndex(CallLog.Calls.DURATION));
        	 if(date>now-7*24*60*60*1000){
        		 if(Integer.parseInt(type)==1){
        			 in_flag=0;
        			 type="着信";
        			 duration_sum=duration_sum+duration;
        			 for(i=0;i<in_sum;i++){
        				 if(in_name[i].equals(number)){
        					 in_duration[i][in_count[i]]=duration;
        					 in_count[i]++;
        					 in_flag=1;
        					 if(in_max<duration)
        						 in_max=duration;
        					 break;
        				 }
        			 }
        			 if(in_flag==0){
        				 in_name[in_sum]=number;
        				 in_duration[in_sum][in_count[in_sum]]=duration;
        				 in_count[in_sum]++;
        				 in_sum++;
        				 if(in_max<duration)
        					 in_max=duration;
        			 }
        		 }
        		 else if(Integer.parseInt(type)==2){
        			 type="発信";
        			 duration_sum=duration_sum+duration;
        			 out_calling++;
        			 out_flag=0;
        			 for(i=0;i<out_sum;i++){
        				 if(out_name[i].equals(number)){
        					 out_duration[i][out_count[i]]=duration;
        					 out_count[i]++;
        					 out_flag=1;
        					 if(out_max<duration)
        						 out_max=duration;
        					 break;
        				 }
        			 }
        			 if(out_flag==0){
        				 out_name[out_sum]=number;
        				 out_duration[out_sum][out_count[out_sum]]=duration;
        				 out_count[out_sum]++;
        				 out_sum++;
        				 if(out_max<duration)
        					 out_max=duration;
        			 }
        		 }
        		 else if(Integer.parseInt(type)==3)
        			 type="不在着信";
        	 }
         } while (c.moveToNext());
         //Log.v("MeasureActivity1","発信回数："+out_calling);
         if(out_calling>base_NP*2/5*4)
        	 value_NP=5;
         else if(out_calling>base_NP*2/5*3)
        	 value_NP=4;
         else if(out_calling>base_NP*2/5*2)
        	 value_NP=3;
         else if(out_calling>base_NP*2/5*1)
        	 value_NP=2;
         else if(out_calling<base_NP*2/5*1)
        	 value_NP=1;
         np1.setText(""+out_calling);
         Log.v("MeasureActivity","NP測定完了");
         
     
         if(duration_sum>base_FC*2*4/5)
        	 value_FC=5;
         else if(duration_sum>base_FC*2*3/5)
        	 value_FC=4;
         else if(duration_sum>base_FC*2*2/5)
        	 value_FC=3;
         else if(duration_sum>base_FC*2*1/5)
        	 value_FC=2;
         else if(duration_sum<base_FC*2*1/5)
        	 value_FC=1;
         Log.v("MeasureActivity","合計通話時間："+duration_sum);
         fc1.setText(""+duration_sum);
         Log.v("MeasureActivity","FC測定完了");
         
         if(out_max>in_max)
        	 call_max=out_max;
         else
        	 call_max=in_max;
         if(call_max>base_AC*2/5*4)
        	 value_AC=5;
         else if(call_max>base_AC*2/5*3)
        	 value_AC=4;
         else if(call_max>base_AC*2/5*2)
        	 value_AC=3;
         else if(call_max>base_AC*2/5*1)
        	 value_AC=2;
         else if(call_max<base_AC*2/5*1)
        	 value_AC=1;
         Log.v("MeasureActivity","一人ずつの通話時間："+call_max);
         ac1.setText(""+call_max);
         Log.v("MeasureActivity","AC測定完了");

     }
	}
}
