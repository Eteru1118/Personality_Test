package com.example.personalitytest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.content.*;
import android.view.*;
import android.util.*;
 
public class DrawActivity extends View{
  public DrawActivity(Context context, AttributeSet attrs){	  
    super(context,attrs);
    try {
        FileInputStream fileInputStream;
        fileInputStream = openFileInput("test.txt");
        byte[] readBytes = new byte[fileInputStream.available()];
        fileInputStream.read(readBytes);
        String readString = new String(readBytes);
        Log.v("readString", readString);
    } catch (FileNotFoundException e) {
    } catch (IOException e) {
    }
    setFocusable(true);
  }
   
  private FileInputStream openFileInput(String string) {
	// TODO 自動生成されたメソッド・スタブ
	return null;
}

protected void onDraw(Canvas canvas){
    super.onDraw(canvas);
    //canvas.drawColor(Color.WHITE);
    
    Paint paint = new Paint();
    paint.setAntiAlias(true);
    paint.setColor(Color.RED);
    canvas.drawLine(100, 100, 200, 300, paint);
  }
}